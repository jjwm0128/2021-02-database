const slider = document.getElementById("js-range");
const num = document.getElementById("num");
const printForm = document.getElementById("js-guess-button");
const display=document.getElementById("js-result");
let machine_num = 0;
let choose_num = 0;
num.innerHTML=slider.value;


slider.oninput = function ()
{
    num.innerHTML=this.value;
}
const random_generator = (max_value) => Math.floor((Math.random() * (max_value + 1)));

const handleprint = (e) =>
{
    e.preventDefault();

    machine_num = random_generator(Number(slider.value));
    choose_num=Number(document.getElementById("play").value);
    const displaySpan=display.querySelector("span");
    displaySpan.innerHTML = `
    You choose: ${choose_num} the machine choose: ${machine_num}<br>`;
    if (choose_num > machine_num) 
    {
        displaySpan.innerHTML += '<b>You won!</b>';
    }
    else if(choose_num===machine_num)
    {
        displaySpan.innerHTML += '<b>Draw!</b>';
    }
    else
    {
        displaySpan.innerHTML += '<b>You lost!</b>';
    }
};

printForm.addEventListener("click", handleprint);
